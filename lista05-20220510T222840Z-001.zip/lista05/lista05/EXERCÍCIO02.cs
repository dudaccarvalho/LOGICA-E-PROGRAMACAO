﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lista05
{
    public partial class EXERCÍCIO02 : Form
    {
        public EXERCÍCIO02()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtB.Clear();   
            txtH.Clear();

            lblresult2.Text = "";
            lblresult1.Text = "";
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            float varBase = float.Parse(txtB.Text);
            float varAltura = float.Parse(txtH.Text);
            float perimetro;
            float area;

            perimetro = (varBase + varAltura);

            area = (varBase * varAltura);

            lblresult1.Text = "O resultado da área do triângulo é: " + area;
            lblresult2.Text = "O resultado da base do triângulo é: " + perimetro;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnEncerrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("OBRIGADA POR UTILIZAR MEU PROGRAMA! :)");
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
