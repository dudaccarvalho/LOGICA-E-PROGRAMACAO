﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lista05
{
    public partial class EXERCÍCIO01 : Form
    {
        public EXERCÍCIO01()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            float varQuadrado = float.Parse(txtnum.Text);
            double result;
            float expo;

            expo = 2;

            result = Math.Pow(varQuadrado, expo);

            lblresult.Text = "O valor do quadrado do número é: " + result + " m².";

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtnum.Clear();
            lblresult.Text = "";
        }

        private void btnencerrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("OBRIGADA POR USAR MEU PROGRAMA! :)");
        }
    }
}
